package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices {
	public void sayHello(String personName) {
		System.out.println("Hello " + personName);
	}
	public void goodBye(String personName) {
		System.out.println("GoodBye " + personName);	
	}

}
