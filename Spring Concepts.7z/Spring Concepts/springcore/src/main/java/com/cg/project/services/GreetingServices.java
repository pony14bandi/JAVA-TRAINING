package com.cg.project.services;

public interface GreetingServices {
	void sayHello(String personName);
	void goodBye(String personName);

}
