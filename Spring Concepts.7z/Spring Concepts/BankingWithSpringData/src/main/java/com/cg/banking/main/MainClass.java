package com.cg.banking.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.PayloadApplicationEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) applicationContext.getBean("bankingServices");
		int customerId = bankingServices.acceptCustomerDetails("Poornima", "Pony", "pony@gmail", "90jrjrh", "pune", "maharashtra", 504332, "hyd", "telangana", 502032);
		int customerId1 = bankingServices.acceptCustomerDetails("PoornimaDil", "Pony", "pony@gmail", "90jrjrh", "pune", "maharashtra", 504332, "hyd", "telangana", 502032);
		long accountNo= bankingServices.openAccount(customerId, "savings", 30000);
		long accountNo1=bankingServices.openAccount(customerId, "salary", 10000);
		long accountNo2=bankingServices.openAccount(2, "savings", 20000);
		System.out.println(bankingServices.getCustomerDetails(1));
		System.out.println(bankingServices.getAccountDetails(customerId,accountNo));
		System.out.println(bankingServices.getAllCustomerDetails());
		System.out.println(bankingServices.getcustomerAllAccountDetails(customerId));
		float bal=bankingServices.depositAmount(1, 1, 800);
		System.out.println(bal);
		int pin1 = bankingServices.generateNewPin(customerId1, accountNo1);
		bankingServices.withdrawAmount(customerId1, accountNo1, 1000, pin1);
		bankingServices.fundTransfer(customerId1, accountNo2, customerId, accountNo1, 1000,pin1 );
		bankingServices.changeAccountPin(customerId1, accountNo1, pin1, 1234);
		System.out.println(bankingServices.getAccountAllTransaction(customerId, accountNo));
		bankingServices.removeCustomer(customerId);
		bankingServices.closeAccount(customerId, accountNo);
		
	}
}
	