package com.cg.banking.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.banking.beans.*;
public interface BankingDAOServices2 extends JpaRepository<Transaction, Integer>{
	
}