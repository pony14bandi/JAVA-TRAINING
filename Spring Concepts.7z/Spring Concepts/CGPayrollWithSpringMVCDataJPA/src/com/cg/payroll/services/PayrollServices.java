package com.cg.payroll.services;


import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;

public interface PayrollServices {

	int acceptAssociate(Associate associate)throws PayrollServicesDownException;

	boolean doUpdateAssociate(Associate associate)
			throws AssociateDetailsNotFoundException,PayrollServicesDownException;
	double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	boolean doDeleteAssociate(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException;

	List<Associate> getAllAssociateDetails() throws PayrollServicesDownException;

}