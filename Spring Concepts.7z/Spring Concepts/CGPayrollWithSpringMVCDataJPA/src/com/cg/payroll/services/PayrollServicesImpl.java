package com.cg.payroll.services;
import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.*;
@Component(value="payrollServices")
public class PayrollServicesImpl implements PayrollServices{
	@Autowired
	private PayrollDAOServices payrollDAOServices;
	@Transactional
	@Override
	public int acceptAssociate(Associate associate) throws PayrollServicesDownException{
		return  payrollDAOServices.save(associate).getAssociateId();
	}
	
	public boolean doUpdateAssociate(Associate associate)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
			payrollDAOServices.saveAndFlush(associate);
			return true;
	}
	@Transactional
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		if(getAssociateDetails(associateId)==null)
			throw new AssociateDetailsNotFoundException("Associate with associateId "+associateId+"not found");
		double personalAllowance,conveyanceAllowance,otherAllowance,grossSalary,annualSalary,tax,epf,companypf,basicSalary,yearlyInvestmentUnder80C,i,j;
		Associate associate;
		associate = payrollDAOServices.findOne(associateId);
		System.out.println(associate);
		epf=associate.getSalary().getEpf();
		basicSalary=associate.getSalary().getBasicSalary();
		companypf=associate.getSalary().getCompanyPf();
		yearlyInvestmentUnder80C=associate.getYearlyInvestmentUnder80C();
		personalAllowance=0.3*basicSalary;
		conveyanceAllowance=0.2*basicSalary;
		otherAllowance=0.1*basicSalary;
		grossSalary=basicSalary+(0.25*basicSalary)+personalAllowance+conveyanceAllowance+otherAllowance+companypf;
		annualSalary=grossSalary*12;
		associate.getSalary().setHra((0.25*basicSalary));
		associate.getSalary().setGratuity((0.05*basicSalary));
		associate.getSalary().setConveyenceAllowance(conveyanceAllowance);
		associate.getSalary().setGrossSalary(grossSalary);
		associate.getSalary().setOtherAllowance(otherAllowance);
		associate.getSalary().setPersonalAllowance(personalAllowance);
		j=yearlyInvestmentUnder80C+12*(companypf+epf);	
		if(j>=150000)
			j=150000;
		if(annualSalary<250000){
			associate.getSalary().setMonthlyTax(0);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			payrollDAOServices.saveAndFlush(associate);
			return (grossSalary-epf-companypf);
		}
		else if(annualSalary>=250000&&annualSalary<500000){
			i=(annualSalary-250000-j);
			if(i<=0)
				tax=0;
			else
				tax=(0.1*i)/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			payrollDAOServices.saveAndFlush(associate);
			return (grossSalary-epf-companypf-tax);
		}
		else if(annualSalary>=500000&&annualSalary<1000000){
			i=(250000-j)*0.1;
			tax=(((annualSalary-500000)*0.2)+i)/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			payrollDAOServices.saveAndFlush(associate);
			return (grossSalary-epf-companypf-tax);
		}
		else if(annualSalary>=1000000){
			i=(250000-j)*0.1;
			tax=(i+100000+((annualSalary-1000000)*0.3))/12;
			associate.getSalary().setMonthlyTax(tax);
			associate.getSalary().setNetSalary((grossSalary-epf-companypf));
			payrollDAOServices.saveAndFlush(associate);
			return (grossSalary-epf-companypf-tax);
		}
		return 0;
	}
	@Override
	public boolean doDeleteAssociate(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		if(payrollDAOServices.findOne(associateId)==null)
			throw new AssociateDetailsNotFoundException("Associate with asssociateId "+associateId+"not found");
		payrollDAOServices.delete(associateId);
		return true;
	}
	@Transactional
	@Override
	public Associate getAssociateDetails(int associateId)throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		if(payrollDAOServices.findOne(associateId)==null)
			throw new AssociateDetailsNotFoundException("Associate with associateId "+ associateId+"not found");
		return payrollDAOServices.findOne(associateId);
	}
	@Transactional
	@Override
	public List<Associate> getAllAssociateDetails() throws  PayrollServicesDownException{
		return payrollDAOServices.findAll();
	}
}