package com.cg.payroll.controllers;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;
import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.*;

@ControllerAdvice(basePackages= {"com.cg.payroll.controller"})
public class ExceptionHandlerAspect {
	@ExceptionHandler(AssociateDetailsNotFoundException.class)
	public ModelAndView handleAssociateDetailsNotFoundException(Associate associate) {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("loginPage");
		modelAndView.addObject("associate", new Associate());
		return modelAndView;
	}
	@ExceptionHandler(PayrollServicesDownException.class)
	public String handlePayrollServicesDownException(Associate associate) {
		return "errorPage";
	}
}


