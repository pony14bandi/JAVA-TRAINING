package com.cg.payroll.controllers;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.PayrollServices;
@Controller
public class LoginController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/loginUser",method=RequestMethod.POST)
	public String loginUser(@Valid @ModelAttribute("associate") Associate associate,BindingResult result) throws AssociateDetailsNotFoundException, PayrollServicesDownException{
			if(associate.getPassword().equals(payrollServices.getAssociateDetails(associate.getAssociateId()).getPassword())){
				return "successPage";
			}
			return "errorPage";
	}
}