package com.cg.payroll.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
@Controller
public class URIController {
	@RequestMapping("/")
	public String getIndexPage(){
		return "indexPage";
	}
	@RequestMapping("/login")
	public String getLoginPage(){
		return "loginPage";
	}
	@RequestMapping("/registration")
	public String getRegistrationPage(){
		return "registrationPage";
	}
	@RequestMapping("/update")
	public String getUpdatePage(){
		return "updatePage";
	}
	@ModelAttribute("associate")
	public Associate getAssociate(){
		return new Associate();
	}
}
