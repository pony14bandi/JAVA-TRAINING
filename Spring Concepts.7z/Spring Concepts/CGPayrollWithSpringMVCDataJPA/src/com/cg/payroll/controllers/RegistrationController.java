package com.cg.payroll.controllers;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.InvalidDataException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
@Controller
public class RegistrationController {
	@Autowired
	PayrollServices payrollServices;
	@RequestMapping(value="/registerUser")
	public String registerUser(@Valid @ModelAttribute("associate") Associate associate,BindingResult result) throws PayrollServicesDownException, InvalidDataException{

		/*if(result.hasErrors())return "registrationPage";
		payrollServices.acceptAssociate(associate);
		return "successPage";
	*/
		try{
				if(result.hasFieldErrors("firstName"))
					System.out.println("firstName");
				if(result.hasFieldErrors("lastName"))
					System.out.println("lastName");
				if(result.hasFieldErrors("department"))
					System.out.println("department");
				if(result.hasFieldErrors("designation"))
					System.out.println("designation");
				if(result.hasFieldErrors("pancard"))
					System.out.println("pancard");
				if(result.hasFieldErrors("emailId"))
					System.out.println("emailId");
				if(result.hasFieldErrors("yearlyInvestmentUnder80C"))
					System.out.println("yearlyInvestmentUnder80C");
				else if(result.hasFieldErrors("bankdetails.bankName"))
					System.out.println("bankdetails.bankName");
				else if(result.hasFieldErrors("bankdetails.accountNumber"))
					System.out.println("bankdetails.accountNumber");
				else if(result.hasFieldErrors("bankdetails.ifscCode"))
					System.out.println("bankdetails.ifscCode");
				else if(result.hasFieldErrors("salary.basicSalary"))
					System.out.println("salary.basicSalary");
				else if(result.hasFieldErrors("salary.epf"))
					System.out.println("salary.epf");
				else if(result.hasFieldErrors("salary.companyPf"))
					System.out.println("salary.companyPf");
				return "registrationPage";	
			payrollServices.acceptAssociate(associate);
			return "successPage";
	}
	}
}

