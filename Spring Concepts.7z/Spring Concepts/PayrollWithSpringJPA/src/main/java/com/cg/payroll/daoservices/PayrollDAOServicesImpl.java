package com.cg.payroll.daoservices;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.payroll.beans.*;
@Component(value="payrollDAOServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired(required=true)
	private EntityManagerFactory entityManagerFactory;

	@Override
	public int insertAssociate(Associate associate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.persist(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return associate.getAssociateId();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		entityManager.merge(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		return true;
	}

	@Override
	public boolean deleteAssociate(int associateId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		entityManager.getTransaction().begin();
		Associate associate= entityManager.find(Associate.class, associateId);
		entityManager.remove(associate);
		entityManager.flush();
		entityManager.getTransaction().commit();
		entityManager.close();
		
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		return entityManager.find(Associate.class,associateId);
	}

	@Override
	public List<Associate> getAssociates() {
		EntityManager entityManager = entityManagerFactory.createEntityManager();
		TypedQuery<Associate> query = entityManager.createQuery("from Associate a",Associate.class);
		return query.getResultList();
	}
	
}