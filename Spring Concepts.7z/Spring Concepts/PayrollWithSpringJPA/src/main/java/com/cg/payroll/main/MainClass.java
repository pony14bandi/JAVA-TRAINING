package com.cg.payroll.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.InvalidDataException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
public class MainClass {
	public static void main(String args[]) throws PayrollServicesDownException, InvalidDataException, AssociateDetailsNotFoundException{
	 ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		PayrollServices payrollServices = (PayrollServices) applicationContext.getBean("payrollServices");
		int associateId=payrollServices.acceptAssociate(150000, "Pony", "Poornima", "IT", "JrCon", "PJU8776", "pony@gmail", 30000, 1000, 1000, 100987, "ICICI", "ICI005");
		int associateId1=payrollServices.acceptAssociate(150000, "Poornima", "Pony", "IT", "JrCon", "PJU8776", "pony@gmail", 54000, 1000, 1000, 399309, "ICI", "ICI08905");
		int associateId2=payrollServices.acceptAssociate(150055, "Dileep", "Pony", "ECE", "JrCon", "gats736", "dil@gmail", 50000, 1000, 1000, 399309, "ICI", "ICI08905");
		payrollServices.calculateNetSalary(3);
		payrollServices.doUpdateAssociate(3, 150000, "Srikanth", "Pony", "IT", "JrCon", "PJU8776", "pony@gmail", 54000, 1000, 1000, 399309, "ICI", "ICI08905");
		System.out.println(payrollServices.getAssociateDetails(3));
		System.out.println(payrollServices.doDeleteAssociate(2));
		System.out.println(payrollServices.getAllAssociateDetails());
		
	       
		
	}
}
