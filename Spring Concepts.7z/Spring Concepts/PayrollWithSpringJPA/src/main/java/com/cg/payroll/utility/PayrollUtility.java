package com.cg.payroll.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Random;

import com.cg.payroll.exceptions.PayrollServicesDownException;

public class PayrollUtility{
	private static Random rand = new Random();
}
