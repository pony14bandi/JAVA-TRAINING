package com.cg.banking.main;
import org.springframework.context.ApplicationContext;
import org.springframework.context.PayloadApplicationEvent;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) applicationContext.getBean("bankingServices");
		int customerId = bankingServices.acceptCustomerDetails("Poornima", "Pony", "pony@gmail", "90jrjrh", "pune", "maharashtra", 504332, "hyd", "telangana", 502032);
		int customerId1 = bankingServices.acceptCustomerDetails("PoornimaDil", "Pony", "pony@gmail", "90jrjrh", "pune", "maharashtra", 504332, "hyd", "telangana", 502032);
		long accountNo= bankingServices.openAccount(1, "savings", 30000);
		long accountNo1=bankingServices.openAccount(1, "salary", 10000);
		System.out.println(bankingServices.getCustomerDetails(1));
		System.out.println(bankingServices.getAccountDetails(1, 1));
		System.out.println(bankingServices.getAllCustomerDetails());
		System.out.println(bankingServices.getcustomerAllAccountDetails(1));
		float bal=bankingServices.depositAmount(1, 1, 800);
		System.out.println(bal);
		
		
	}
}
	