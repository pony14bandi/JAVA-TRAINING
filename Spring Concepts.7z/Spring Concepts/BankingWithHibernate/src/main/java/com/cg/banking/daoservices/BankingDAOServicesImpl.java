package com.cg.banking.daoservices;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.*;
import com.cg.banking.utility.BankingUtility;
@Component(value="bankingDAOServices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private org.hibernate.Transaction tx;
	@Override
	public int insertCustomer(Customer customer) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			int custId=(int) session.save(customer);
			tx.commit();
			return custId;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}

	}
	@Override
	public long insertAccount(int customerId, Account account) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Customer customer=(Customer) session.get(Customer.class, customerId);
			account.setCustomer(customer); 
			account.setStatus("active");
			long acctId= (long) session.save(account);
			tx.commit();
			return acctId;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Account account = (Account) session.get(Account.class, accountNo);
			transaction.setAccount(account);
			int txId= (int) session.save(transaction);
			tx.commit();
			return true;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		try{
			session=sessionFactory.openSession();
			tx= session.beginTransaction();
			Customer customer=getCustomer(customerId);
			account.setCustomer(customer);
			session.update(account);
			tx.commit();
			return true;
		}
		catch(HibernateException e){
			e.printStackTrace();
			tx.rollback();
			throw e;
		}
		finally{
			session.close();
		}
	}
	
	@Override
	public boolean deleteCustomer(int customerId) {
		session=sessionFactory.openSession();
		Customer customer=getCustomer(customerId);
		session.delete(customer);
		session.flush();
		return true;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Account account=getAccount(customerId, accountNo);
		session.delete(account);
		session.flush();
		return true;
	}

	@Override
	public Customer getCustomer(int customerId) {
		session=sessionFactory.openSession();
		Customer customer= (Customer) session.get(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Account account= (Account) session.get(Account.class, accountNo);
		return account;

	}
	@Override
	public List<Customer> getCustomers() {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Customer c");
		return query.list();
	} 
	@Override
	public List<Account> getAccounts(int customerId) {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Account a");
		return query.list();
	}
	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		Query query=session.createQuery("from Transaction b");
		return query.list();
	}
	@Override
	public int generatePin(int customerId, Account account) {
		account.setPinNumber(BankingUtility.rand.nextInt(9999));
		updateAccount(customerId, account);
		return account.getPinNumber(); 
	}
	

}
