package com.cg.LoginSeleniumTest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import junit.framework.Assert;
public class LoginTest {
	static WebDriver driver;
	private LoginPage loginPage;
	@BeforeClass
	public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTestEnv(){
		driver.get("https://github.com/session");
		loginPage = new LoginPage();
		PageFactory.initElements(driver,loginPage);
	}
	@Test
	public  void testForBlankUserNameAndPassword(){
		loginPage.setUsername("");
		loginPage.setPassword("");
		loginPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='container']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "Incorrect username or password";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testInvalidUsername(){
		loginPage.setUsername(getInvalidUsername());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='container']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "Incorrect username or password";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	private String getValidPassword() {
		return "Dileep0104";
	}
	private String getInvalidUsername() {
		return "poornima";
	}
	@Test
	public void testInvalidPassword(){
		loginPage.setUsername(getValidUsername());
		loginPage.setPassword(getInvalidPassword());
		loginPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='container']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "Incorrect username or password";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	private String getInvalidPassword() {
		return "poornima";
	}
	private String getValidUsername() {
		return "pony14bandi";
	}
	@Test
	public void testValidUserNameAndPassword(){
		loginPage.setUsername(getValidUsername());
		loginPage.setPassword(getValidPassword());
		loginPage.clickSubmitButton(); 
		String actualMessage=driver.findElement(By.xpath("//meta[@name='user-login']" )).getAttribute("content");  
		System.out.println("Message :-" +actualMessage);
		String expectedMessage = "pony14bandi";
		Assert.assertNotSame(expectedMessage, actualMessage);
	}
	
	@After
	public void tearDownEnv(){
/*		loginPage=null;
*/	}
	@AfterClass
	public static void tearDownDriverEnv(){
		/*driver.close();
		driver=null;*/
	}
}

