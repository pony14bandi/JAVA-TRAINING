package com.cg.LoginSeleniumTest;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import junit.framework.Assert;
public class RegisterTest {
	static WebDriver driver;
	private RegisterPage registerPage;
	@BeforeClass
	public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTestEnv(){
		driver.get("https://github.com/join?source=header-home");
		registerPage = new RegisterPage();
		PageFactory.initElements(driver,registerPage);
	}
	@Test
	public  void testForBlankUserNameAndEmailAndPassword(){
		registerPage.setUsername("");
		registerPage.setPassword("");
		registerPage.setEmailID("");
		registerPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Login can't be blank,Email can't be blank,Password can't be blank and is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForInvalidUserNameAndPasswordAndValidEmailID(){
		registerPage.setUsername("kiran");
		registerPage.setPassword("kiran");
		registerPage.setEmailID("kiran.2@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
		}
	@Test
	public void testForInvalidUserNameAndPasswordAndEmailID(){
		registerPage.setUsername("kiran");
		registerPage.setPassword("kiran");
		registerPage.setEmailID("kiran@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Username is already taken,Email is invalid or already taken,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);	
	}
	@Test
	public void testForInvalidPasswordAndValidUserNameAndEmail(){
		registerPage.setUsername("kiran1233");
		registerPage.setPassword("kiran");
		registerPage.setEmailID("kiran.2@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForInvalidPasswordAndEmailValidUserName(){
		registerPage.setUsername("kiran1233");
		registerPage.setPassword("kiran");
		registerPage.setEmailID("kiran@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage = driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")). getText();
		System.out.println("error Message :-" +actualErrorMessage);
		String expectedErrorMessage = "There were problems creating your account.,Password is too short (minimum is 7 characters)";
		Assert.assertNotSame(expectedErrorMessage, actualErrorMessage);
	}
	@Test
	public void testForValidUserNameAndPassword(){
		registerPage.setUsername("kiran1233");
		registerPage.setPassword("Kiran12345");
		registerPage.setEmailID("kiran.2@gmail.com");
		registerPage.clickSubmitButton();
	}
	@After
	public void tearDownEnv(){
		registerPage=null;
	}
	@AfterClass
	public static void tearDownDriverEnv(){
		driver.close();
		driver=null;
	}
}
