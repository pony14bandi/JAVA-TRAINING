package com.cg.payroll.main;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.*;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		PayrollServices payrollServices = new PayrollServicesImpl();
		int AssociateId=payrollServices.acceptAssociateDetails("POORNIMA", "BANDI", "IT", "SOFTWARE", "HHEOH789", "poornima@cg.com", 150000, 50000, 1000, 1000, 234545, "ICICI", "ICIC001");
		System.out.println(AssociateId);
		payrollServices.calculateNetSalary(AssociateId);
		System.out.println("Monthly tax= " +payrollServices.getAssociateDetails(AssociateId).getSalary().getMonthlyTax());
		System.out.println(payrollServices.getAssociateDetails(AssociateId).getSalary().getGratuity()+" "+payrollServices.getAssociateDetails(AssociateId).getSalary().getOtherAllowance()+" "+payrollServices.getAssociateDetails(AssociateId).getSalary().getNetSalary());
		int AssociateId1=payrollServices.acceptAssociateDetails("PONY", "PONY", "SOFTWARE", "ENGINEER", "PPIT86", "pony@cg", 50000, 30000, 1000, 1000, 987654, "HDFC", "HD123");
		System.out.println(AssociateId1);
		payrollServices.calculateNetSalary(AssociateId1);
		System.out.println(payrollServices.getAssociateDetails(AssociateId1).getSalary().getMonthlyTax());
	}

}
