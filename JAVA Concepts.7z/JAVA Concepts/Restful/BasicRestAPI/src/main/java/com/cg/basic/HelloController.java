package com.cg.basic;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.RequestMapping;
@RestController
@RequestMapping("api/v1/")
public class HelloController {
		@RequestMapping(method=RequestMethod.GET,value="hello")
		public String[] sayHello() {
			return new String[] {"Hello","World!"};
		}
}
