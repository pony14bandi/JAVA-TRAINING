package com.cg.flight;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.flight.model.Flightwreck;

public class FlightDetailsStub {
	private static Map<Long, Flightwreck> wrecks = new HashMap<Long, Flightwreck>();
	private static Long idIndex =  (long) 1003;
	static {
		Flightwreck a = new Flightwreck(1001L, "AirIndia", "Mumbai", "Goa", "08/06/2018", "10/06/2018", "Economy", "RoundTrip");
		wrecks.put((long) 1001, a);
		Flightwreck b = new Flightwreck(1002L, "Indigo", "Hyderabad", "Pune", "11/06/2018", " ", "Business", "OneWay");
		wrecks.put((long) 1002, b);
		Flightwreck c = new Flightwreck(1003L, "SpiceJet", "Vizag", "Hyderabad", "21/06/2018", "30/06/2018", "FirstClass", "RoundTrip");
		wrecks.put((long) 1003, c);
	}

	public static List<Flightwreck> list() {
		return new ArrayList<Flightwreck>(wrecks.values());
	}

	public static Flightwreck create(Flightwreck wreck) {
		idIndex += idIndex;
		wreck.setFlightNo(idIndex);
		wrecks.put(idIndex, wreck);
		return wreck;
	}

	public static Flightwreck get(Long flightNo) {
		return wrecks.get(flightNo);
	}

	public static Flightwreck update(Long  flightNo,Flightwreck wreck) {
		wrecks.put(flightNo, wreck);
		return wreck;
	}

	public static Flightwreck delete(Long  flightNo) {
		return wrecks.remove(flightNo);
	}
}
