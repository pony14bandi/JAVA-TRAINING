package com.cg.flight.model;
public class Flightwreck {
	Long flightNo;
	String flightName;
	String fromLocation;
	String toLocation;
	String startDate;
	String returnDate;
	String passengerClass;
	String tripType;
	public Flightwreck() {}
	public Flightwreck(Long flightNo, String flightName, String fromLocation, String toLocation, String startDate,
			String returnDate, String passengerClass, String tripType) {
		super();
		this.flightNo = flightNo;
		this.flightName = flightName;
		this.fromLocation = fromLocation;
		this.toLocation = toLocation;
		this.startDate = startDate;
		this.returnDate = returnDate;
		this.passengerClass = passengerClass;
		this.tripType = tripType;
	}
	public Long getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(Long flightNo) {
		this.flightNo = flightNo;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFromLocation() {
		return fromLocation;
	}
	public void setFromLocation(String fromLocation) {
		this.fromLocation = fromLocation;
	}
	public String getToLocation() {
		return toLocation;
	}
	public void setToLocation(String toLocation) {
		this.toLocation = toLocation;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	public String getPassengerClass() {
		return passengerClass;
	}
	public void setPassengerClass(String passengerClass) {
		this.passengerClass = passengerClass;
	}
	public String getTripType() {
		return tripType;
	}
	public void setTripType(String tripType) {
		this.tripType = tripType;
	}
	
	}
