package com.cg.flight;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.flight.model.Flightwreck;
@RequestMapping("api/v1/")
@RestController
@CrossOrigin(origins="*")
public class FlightController {
		@RequestMapping(value="flight", method=RequestMethod.POST)
//		@ResponseBody
		public Flightwreck save(@RequestBody Flightwreck wreck){
			return FlightDetailsStub.create(wreck);
		}
		@RequestMapping(value="flight",method=RequestMethod.GET)
		public List<Flightwreck> get(){	
			return FlightDetailsStub.list();
		}	
		@RequestMapping(value="flight/{flightNo}",method=RequestMethod.PUT)
		public Flightwreck saveAndFlush(@RequestBody Flightwreck wreck) {
			return FlightDetailsStub.update(wreck.getFlightNo(), wreck);	
		}
		@RequestMapping(value="flight/{flightNo}",method=RequestMethod.GET)
		public Flightwreck get(@PathVariable("flightNo") long flightNo ) {
			return FlightDetailsStub.get(flightNo);	
		}
		@RequestMapping(value="flight/{flightNo}",method=RequestMethod.DELETE)
		public Flightwreck delete(@PathVariable("flightNo") long flightNo) {
			return FlightDetailsStub.delete(flightNo);
		}
}
