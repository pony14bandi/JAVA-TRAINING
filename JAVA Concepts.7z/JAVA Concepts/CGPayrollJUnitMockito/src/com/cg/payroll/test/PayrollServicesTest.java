package com.cg.payroll.test;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;



public class PayrollServicesTest {
	private static PayrollServices payrollServices;
	private static PayrollDAOServices mockDAOServices;
	@BeforeClass
	public static void SetUpPayrollServices(){
		mockDAOServices=Mockito.mock(PayrollDAOServices.class);
		payrollServices = new PayrollServicesImpl(mockDAOServices);
	}
	@Before
	public void setUpMockData(){
		Associate associate1=new Associate(10001, 150000, "Poornima", "Godishala", "IT", "SOFTWARE", "POJU876", "pony@capg",new Salary(50000,1000,1000),new BankDetails(123007, "ICICI", "ICI100"));
		Associate associate2=new Associate(10002, 150000, "Poornima", "Bandi", "IT", "SOFTWARE", "JGU896HD", "poornima@capg",new Salary(30000,1000,1000),new BankDetails(123307, "HDFC", "HDF100"));

		ArrayList<Associate> associateList = new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		Associate associate3=new Associate(10003, 150000, "Dileep", "Godishala", "IT", "SOFTWARE ENGINEER", "JGHDS96HD", "dileep@capg",new Salary(70000,1000,1000),new BankDetails(123307, "SC", "SC1040"));
		
		
		Mockito.when(mockDAOServices.getAssociate(10001)).thenReturn(associate1);
		Mockito.when(mockDAOServices.getAssociate(10002)).thenReturn(associate2);
		Mockito.when(mockDAOServices.getAssociate(10003)).thenReturn(null);
		Associate associate4=new Associate(150000, "Dileep", "Godishala", "IT", "SOFTWARE ENGINEER", "JGHDS96HD", "dileep@capg",new Salary(70000,1000,1000),new BankDetails(123307, "SC", "SC1040"));
		Mockito.when(mockDAOServices.insertAssociate(associate4)).thenReturn(10004);
	}
	@Test
	public void testValidAssociateIdCheck() throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		payrollServices.getAssociateDetails(10001);
		Mockito.verify(mockDAOServices).getAssociate(10001);	
	}
	
	@Test
	public void testAssociateId(){
		Associate associate4=new Associate(150000, "Dileep", "Godishala", "IT", "SOFTWARE ENGINEER", "JGHDS96HD", "dileep@capg",new Salary(70000,1000,1000),new BankDetails(123307, "SC", "SC1040"));
		int actualId=payrollServices.acceptAssociateDetails( "Dileep", "Godishala", "IT", "SOFTWARE ENGINEER", "JGHDS96HD", "dileep@capg",150000,70000,1000,1000,123307, "SC", "SC1040");
		Assert.assertEquals(10004,actualId);
		Mockito.verify(mockDAOServices).insertAssociate(associate4);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testInValidAssociateIdCheck() throws AssociateDetailsNotFoundException, PayrollServicesDownException{
		payrollServices.getAssociateDetails(10003);
		Mockito.verify(mockDAOServices).getAssociate(10004);
	}
			
	@After
	public void tearUpMockData(){
		payrollServices.getAllAssociateDetails().clear();
	}
	@AfterClass
	public static void tearUpTestEvn(){
		payrollServices=null;
	}
}
