package com.cg.banking.daoservices;
import com.cg.banking.beans.*;


public class BankingDAOServicesImpl implements BankingDAOServices {
	private static Customer[] customerList = new Customer[5];
	private static int CUSTOMER_ID_COUNTER=001;
	private static int CUSTOMER_IDX_COUNTER=0;
	
	private static int ACCOUNT_ID_COUNTER=001;
	private static int ACCOUNT_IDX_COUNTER=0;
	

	public int insertCustomer(Customer customer){
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++] = customer;
		return customer.getCustomerId();
	}
	@Override
	public long insertAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++)
		if( customerList[i]!=null &&  customerList[i].getCustomerId()== customerId)
			
		
		account.setAccountNo(ACCOUNT_ID_COUNTER++);
		customerList[ACCOUNT_IDX_COUNTER++] = account;
		return account.getAccountNo();
		return 0;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public boolean updateCustomer(Customer customer){
		for(int i=0;i<customerList.length;i++)
			if( customerList[i]!=null &&  customer.getCustomerId() ==  customerList[i].getCustomerId())
				 customerList[i]= customer;
			return true;		
	}
	public boolean deleteCustomer(int  customerId){
		for(int i=0;i< customerList.length;i++)
			if( customerList[i]!=null &&  customerList[i].getCustomerId() == customerId)
				 customerList[i]=null;
			return true;	
	}
	public Customer getCustomer(int  customerId){
		for(int i=0;i< customerList.length;i++)
			if( customerList[i]!=null &&  customerList[i].getCustomerId()==  customerId)
				return  customerList[i];
		
		return null;
	}
	public Customer[] getCustomers(){
		return  customerList;
	}
	
	@Override
	public boolean updateAccount(int customerId, Account account) {
		
		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Account[] getAccounts(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return transactionList;
		return null;
	}

}

}
