package com.cg.payroll.main;
import com.cg.payroll.beans.*;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exception.AssociateDetailsNotFoundException;
import com.cg.payroll.exception.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {


	public static void main(String[] args) throws AssociateDetailsNotFoundException, PayrollServicesDownException {
	
			PayrollServices payrollServices = new PayrollServicesImpl();
			int AssociateId=payrollServices.acceptAssociateDetails("POORNIMA", "BANDI", "IT", "SOFTWARE", "HHEOH789", "poornima@cg.com", 150000, 50000, 1000, 1000, 234545, "ICICI", "ICIC001");
			System.out.println(AssociateId);
			 payrollServices.calculateNetSalary(AssociateId);
			System.out.println("Monthly tax= " +payrollServices.getAssociateDetails(AssociateId).getSalary().getMonthlyTax());
			System.out.println(payrollServices.getAssociateDetails(AssociateId).getSalary().getGratuity()+" "+payrollServices.getAssociateDetails(AssociateId).getSalary().getOtherAllowance()+" "+payrollServices.getAssociateDetails(AssociateId).getSalary().getNetSalary());
	}
		
	}

