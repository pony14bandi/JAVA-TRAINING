package com.cg.payroll.main;
import com.cg.payroll.beans.*;
public class MainArray {
	public static void main(String[] args){	
		int yearlyInvestmentUnder80C=50000;
		String firstName = "POORNIMA";
		float basicSalary = 35000;

		Associate associate = searchInvestment(yearlyInvestmentUnder80C, firstName, basicSalary);
		if(associate!=null)
			System.out.println(associate.getYearlyInvestmentUnder80C()+" "+associate.getFirstName()+" "+ associate.getSalary().getBasicSalary());
		else
			System.out.println("associate details with salary "+yearlyInvestmentUnder80C+" Not Found");
	}
	public static Associate searchInvestment(int yearlyInvestment, String firstName, float  basicSalary ){
		Associate[] associates = new Associate[3];
		associates[0] = new Associate(111, 55600, "POORNIMA", "BANDI", "TRAINING", "SOFTWARE", "8927GWG", "pony@capg.com",new Salary(35676, 6788, 778, 3465, 668898, 6767, 123, 890, 6767, 00, 565),new BankDetails(63546, "ICICI", "ICIC8967"));
		associates[1] = new Associate(114, 55780, "POORNIMA", "GODISHALA", "TRAINING", "SOFTWARE", "4527WERG", "dileep@capg.com",new Salary(35563, 6783528, 77008, 3465, 6698, 6767, 1543, 890, 6767, 73298, 565665),new BankDetails(234546, "HDFC", "ICIC8967"));

		for(Associate associate:associates)
			if(associate.getFirstName() == firstName && associate.getSalary().getBasicSalary()>=basicSalary)
				return associate;
			else
				return null;
		return null;

	}

}
