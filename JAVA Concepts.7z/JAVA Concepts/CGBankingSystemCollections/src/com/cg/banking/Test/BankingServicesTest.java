package com.cg.banking.Test;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.banking.beans.*;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.utility.BankingUtility;
public class BankingServicesTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void SetUpTestEnv(){
		bankingServices = new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		Customer customer1 = new Customer(BankingUtility.CUSTOMER_ID_COUNTER++, "Pony", "POORNIMA", "pony@capg", "pony345", new Address(2344, "pune", "maharashtra") , new Address(6543, "hyd", "telangana"));
		Customer customer2 = new Customer(BankingUtility.CUSTOMER_ID_COUNTER++, "GODISHALA", "DILEEP", "dil@capg", "dil0407", new Address(2098, "pune", "maharashtra") , new Address(1111, "warangal", "telangana"));
		Customer customer3 = new Customer(BankingUtility.CUSTOMER_ID_COUNTER++, "DILEEP", "POORNIMA", "podil@capg", "godisha234", new Address(2344, "mumbai", "maharashtra") , new Address(6543, "hyd", "telangana"));
		Customer customer4 = new Customer(BankingUtility.CUSTOMER_ID_COUNTER++, "SHYAM", "BACHU", "shyam@capg", "shyam123", new Address(2311, "chennai", "tamilnadu") , new Address(6512, "hyd", "telangana"));

		BankingDAOServicesImpl.customers.put(customer1.getCustomerId(), customer1);
		BankingDAOServicesImpl.customers.put(customer2.getCustomerId(), customer2);
		BankingDAOServicesImpl.customers.put(customer3.getCustomerId(), customer3);
		BankingDAOServicesImpl.customers.put(customer4.getCustomerId(), customer4);

		
		Account account1 = new Account("savings", 10000);
		account1.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		account1.setStatus("active");
		account1.setPinNumber(1234);
		BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().put(account1.getAccountNo(), account1);
		Account account2 = new Account("current", 10000);
		account2.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		account2.setStatus("Blocked");
		BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().put(account2.getAccountNo(), account2);
		Account account3 = new Account("current", 10000);
		account3.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		account3.setStatus("active");
		BankingDAOServicesImpl.customers.get(customer3.getCustomerId()).getAccounts().put(account3.getAccountNo(), account3);
		Account account4 = new Account("current", 10000);
		account4.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		account4.setStatus("active");
		BankingDAOServicesImpl.customers.get(customer4.getCustomerId()).getAccounts().put(account4.getAccountNo(), account4);
		
	}
	@Test
	public  void testCustomerId() throws CustomerNotFoundException, BankingServicesDownException{
		Assert.assertEquals(115, bankingServices.acceptCustomerDetails("GODISHALA", "DILEEP", "dil@capg", "dil0407", "pune", "maharashtra",2344, "warangal", "telangana",1111));
	}
	@Test
	public  void testInValidCustomerId() throws CustomerNotFoundException, BankingServicesDownException{
		Assert.assertNotEquals(116,bankingServices.acceptCustomerDetails("Pony", "POORNIMA", "pony@capg", "pony345", "pune", "maharashtra", 2344, "hyd", "telangana", 6543) );
	}
	@Test
	public  void testNegativeCustomerId() throws CustomerNotFoundException, BankingServicesDownException{
		Assert.assertNotEquals(-114, bankingServices.acceptCustomerDetails("Pony", "POORNIMA", "pony@capg", "pony345", "pune", "maharashtra", 2344, "hyd", "telangana", 6543));
	}
	@Test
	public void testCustomerDetails() throws CustomerNotFoundException, BankingServicesDownException{
		Customer customer1 = new Customer(111, "Pony", "POORNIMA", "pony@capg", "pony345", new Address(2344, "pune", "maharashtra") , new Address(6543, "hyd", "telangana"));
		Assert.assertEquals(bankingServices.getCustomerDetails(111), customer1);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerDetails() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServices.getCustomerDetails(115);
	}
	@Test
	public void testAccountNoOpenAccount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "savings", 10000);
	}
	@Test(expected=InvalidAmountException.class)
	public void testInValidAccountNoOpenAccount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "savings", 0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInOpenAccount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(116, "savings", 10000);
	}
	@Test
	public void testValidCustomerInOpenAccount() throws InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(111, "savings", 10000);
	}
	@Test
	public void testValidAccountDetails() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Account account1 = new Account("savings", 10000);
		account1.setAccountNo(10042);
		account1.setStatus("active");
		account1.setPinNumber(1234);
		Assert.assertEquals(bankingServices.getAccountDetails(111, 10042), account1);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testInValidAccountDetails() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		Account account1 = new Account("savings", 1000);
		account1.setAccountNo(10045);
		Assert.assertNotEquals(bankingServices.getAccountDetails(112, 10046), account1);
	}
	@Test
	public void testValidAccountTypeInOpenAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
		Account account1 = new Account("savings", 1000);
		account1.setAccountNo(10042);
		Assert.assertEquals(bankingServices.getAccountDetails(111, 10042).getAccountType(),account1.getAccountType());
	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testInValidAccountTypeInOpenAccount() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, InvalidAmountException, InvalidAccountTypeException{
	bankingServices.openAccount(111, "save", 1000);
	}
	@Test(expected=AccountBlockedException.class)
	public void testInValidAccountStatus() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float amount =  bankingServices.depositAmount(112, 10043, 1000);
		Assert.assertEquals(11000, amount, 0);
	}
	@Test
	public void testValidAmountInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		Account account1 = new Account("savings", 1000);
		account1.setAccountNo(10042);
		account1.setStatus("active");
		int amount = (int) bankingServices.depositAmount(111, 10042, 1000);
		Assert.assertEquals(11000, amount);
	}
	@Test(expected=InvalidAmountException.class)
	public void testInValidAmountInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 10042, 0);
	}
	@Test
	public void testValidCustomerInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 10042, 1000);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(115, 10042, 1000);	
	}
	@Test
	public void testValidAccountNoInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 10042, 1000);
	}
	@Test(expected= AccountNotFoundException.class)
	public void testInValidAccountNoInDeposit() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.depositAmount(111, 10044, 1000);
	}
	
	
	@Test
	public void testValidAmountWithdraw() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float bal=bankingServices.withdrawAmount(111, 10042,1000, 1234);
		Assert.assertEquals(9000, bal, 0);
	}
	@Test(expected=InvalidAmountException.class)
	public void testInValidAmountWithdraw() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.withdrawAmount(111, 10042, 0, 1234);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testInsufficientAmountWithdraw() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.withdrawAmount(111, 10042, 20000, 1234);
	}
	@Test
	public void testValidPinToWithdraw() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.withdrawAmount(111, 10042, 1000, 1234);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testInValidPinToWithdraw() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		float bal = bankingServices.withdrawAmount(111, 10042, 1000,0);
		Assert.assertEquals(10000, bal, 0);
	}
	
	
	
	
	
	
	@Test
	public void testValidCustomerInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(113, 10044, 111, 10042, 1000, 1234);	
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(115, 10043, 111, 10042, 1000, 1234);
	}
	@Test(expected= AccountNotFoundException.class)
	public void testInValidAccountNoInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(112, 10046, 111, 10042, 1000, 1234);
	}
	@Test
	public void testValidPinNoInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(113, 10044, 111, 10042, 1000, 1234);
	}
	
	@Test(expected=InvalidPinNumberException.class)
	public void testInValidPinNoInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(113, 10044, 111, 10042, 1000, 0);
	}
	@Test(expected=InvalidAmountException.class)
	public void testInValidAmountInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(112, 10043, 111, 10042, 0, 1234);
	}
	@Test
	public void testValidAmountInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(113, 10044, 111, 10042, 1000, 1234);
	}
	@Test(expected=InsufficientAmountException.class)
	public void testInsufficientAmountInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(112, 10043, 111, 10042, 15000, 1234);
	}
	@Test
	public void testsufficientAmountInFunds() throws InsufficientAmountException, CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException, InvalidAmountException{
		bankingServices.fundTransfer(113, 10044, 111, 10042, 2000, 1234);
	}
	
	
	
	
	
	
	@Test
	public void testValidCustomerGeneratePin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateNewPin(111, 10042);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerGeneratePin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateNewPin(115, 10042);
	}
	@Test
	public void testValidAccountNoGeneratePin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateNewPin(111, 10042);	
	}
	@Test(expected= AccountNotFoundException.class)
	public void testInValidAccountNoGeneratePin() throws CustomerNotFoundException, AccountNotFoundException, BankingServicesDownException{
		bankingServices.generateNewPin(111, 10046);	
	}
	
	
	@Test
	public void testValidCustomerInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(111, 10042, 1234, 6789);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(116, 10042, 1234, 6789);
	}
	@Test
	public void testValidAccountNoInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(111, 10042, 1234, 6789);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testInValidAccountNoInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(111, 10046, 1234, 6789);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testInValidPinNoInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(111, 10042, 0, 6789);	
	}
	@Test
	public void testValidPinNoInChangePin() throws CustomerNotFoundException, AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.changeAccountPin(111, 10042, 1234, 6789);
	}
	
	
	@Test
	public void testValidCustomerInGetAllCustomerDetails() throws BankingServicesDownException, CustomerNotFoundException{
		bankingServices.getcustomerAllAccountDetails(111);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInGetAllCustomerDetails() throws BankingServicesDownException, CustomerNotFoundException{
		bankingServices.getcustomerAllAccountDetails(116);
	}
	
	
	@Test
	public void testValidCustomerInGetAccountAllTransaction() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getAccountAllTransaction(111, 10042);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInGetAccountAllTransaction() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getAccountAllTransaction(116, 10042);
	}
	@Test
	public void testValidAccountNoInGetAccountAllTransaction() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getAccountAllTransaction(111, 10042);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testInValidAccountNoInGetAccountAllTransaction() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException{
		bankingServices.getAccountAllTransaction(111, 10046);
	}
	@Test
	public void testValidCustomerInAccountStatus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServices.accountStatus(111, 10042);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testInValidCustomerInAccountStatus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServices.accountStatus(116, 10042);
	}
	@Test
	public void testValidAccountNoInAccountStatus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServices.accountStatus(111, 10042);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testInValidAccountNoInAccountStatus() throws BankingServicesDownException, CustomerNotFoundException, AccountNotFoundException, AccountBlockedException{
		bankingServices.accountStatus(111, 10046);
	}
	
	
	@After
	public void tearDownMockData(){
		BankingUtility.CUSTOMER_ID_COUNTER=111;
		BankingUtility.ACCOUNT_ID_COUNTER=10042;
	}
	@AfterClass
	public static void tearDownSetUpEnv(){
		bankingServices= null;
	}

}
