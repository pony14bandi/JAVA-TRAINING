package com.cg.banking.main;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.banking.beans.*;
import com.cg.banking.exceptions.*;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
public class MainClass {
	public static void main(String[] args) throws BankingServicesDownException, InvalidAmountException, CustomerNotFoundException, InvalidAccountTypeException, InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException, AccountBlockedException{
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingServices bankingServices = (BankingServices) applicationContext.getBean("bankingServices");
		
		
		
		/*BankingServicesImpl bankingservices=new BankingServicesImpl();
		int customerId,pinNumber,newPinNumber = 0,oldPinNumber = 0,customerIdTo = 0,customerIdFrom = 0;
		long accountNo,accountNoTo = 0,accountNoFrom = 0;
		float amount;
		int num=0;
		while(num!=11) {
			try {			
				Scanner scanner=new Scanner(System.in);		
				System.out.println("Choose Any Function "+"\n"+
						"1 : Add Customer"+"\n"+
						"2 : Open Account"+"\n"+
						"3 : Generate New Pin"+"\n"+
						"4 : Change Pin"+"\n"+
						"5 : Deposit Money"+"\n"+
						"6 : Withdraw Money"+"\n"+
						"7 : Fund Transfer"+"\n"+
						"8 : Show Balance"+"\n"+
						"9 : View All Customer Details"+"\n"+
						"10 : View Account Detaills"+"\n"+
						"11 : View AllTransaction Details");
				num=scanner.nextInt();
				switch (num) {
				case 1:	
					System.out.println("Enter Customer Details");
					System.out.println("Enter First Name");
					String firstName=scanner.next();
					System.out.println("Enter Last Name");
					String lastName=scanner.next();
					System.out.println("Enter EmailId");
					String emailId=scanner.next();
					System.out.println("Enter PanCard");
					String panCard=scanner.next();
					System.out.println("Enter LocalAddressCity");
					String localAddressCity=scanner.next();
					System.out.println("Enter LocalAddressState");
					String localAddressState=scanner.next();
					System.out.println("Enter LocalAddresspinCode");
					int localAddressPinCode=scanner.nextInt();
					System.out.println("Enter HomeAddresscity");
					String homeAddressCity=scanner.next();
					System.out.println("Enter HomeAddressState");
					String homeAddressState=scanner.next();
					System.out.println("Enter  HomeAddressPinCode");
					int  homeAddressPinCode=scanner.nextInt();
					customerId= bankingservices.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
					System.out.println("CustomerId is" + customerId);
					break;
				case 2:
					System.out.println("Openning An Account");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter AccountType");
					String accountType=scanner.next();
					System.out.println("Enter Initial Balance");
					float initBalance=scanner.nextFloat();
					accountNo=bankingservices.openAccount(customerId, accountType, initBalance);
					System.out.println("Account Number is" + " "+accountNo);
					break;
				case 3:
					System.out.println("Generation Of New Pin");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					int generateNewPin = bankingservices.generateNewPin(customerId, accountNo);
					System.out.println("Generated New Pin"+" "+generateNewPin);
					break;
				case 4:
					System.out.println("Changing Of Pin");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter The Old Pin Number");
					pinNumber=scanner.nextInt();
					System.out.println("Enter the New Pin Number");
					generateNewPin=scanner.nextInt();
					boolean changePin = bankingservices.changeAccountPin(customerId, accountNo, pinNumber, generateNewPin);
					System.out.println("Generated New Pin"+" "+changePin);
					break;
				case 5:
					System.out.println("Depositing Amount");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount To Be Deposited" + " ");
					amount=scanner.nextFloat();
					float depositAmount = bankingservices.depositAmount(customerId, accountNo, amount);
					System.out.println("Balance after depositing" + bankingservices.getAccountDetails(customerId, accountNo).getAccountBalance());
					break;
				case 6:
					System.out.println("Withdrawal Amount");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Enter Amount To Be WithDraw");
					amount=scanner.nextFloat();
					System.out.println("Enter the Pin Number");
					newPinNumber=scanner.nextInt();
					float withdrawAmount = bankingservices.withdrawAmount(customerId, accountNo, amount, newPinNumber);
					System.out.println("Balance after withdrawl" + bankingservices.getAccountDetails(customerId, accountNo).getAccountBalance());
					break;
				case 7:
					System.out.println("Fund Transfer");
					System.out.println("Enter CustomerIdTo");
					customerId=scanner.nextInt();
					System.out.println("Enter AccountNoTo");
					accountNo=scanner.nextLong();
					System.out.println("Enter CustomerIdFrom");
					customerId=scanner.nextInt();
					System.out.println("Enter AccountNoFrom");
					accountNo=scanner.nextLong();
					System.out.println("Enter TransferAmount");
					float transferAmount=scanner.nextFloat();
					System.out.println("Enter the New Pin Number");
					newPinNumber=scanner.nextInt();
					boolean fundTransfer=bankingservices.fundTransfer(customerIdTo, accountNoTo, customerIdFrom, accountNoFrom, transferAmount, newPinNumber);
					System.out.println("Funds Trasfered " + fundTransfer);
					System.out.println("Remaining Balance" +" " + bankingservices.getAccountDetails(customerIdFrom, accountNoFrom).getAccountBalance());
					break;
				case 8:
					System.out.println("Balance In Account");
					System.out.println("Enter CustomerIdTo");
					customerId=scanner.nextInt();
					System.out.println("Enter AccountNoTo");
					accountNo=scanner.nextLong();
					System.out.println("Enter The Old Pin Number");
					pinNumber=scanner.nextInt();
					if(bankingservices.getAccountDetails(customerId, accountNo).getPinNumber()==pinNumber) 
						System.out.println("Balance"+" "+bankingservices.getAccountDetails(customerId, accountNo).getAccountBalance());
					else 
						System.out.println("Entered Wrong Pin");
					break;
				case 9:
					System.out.println("View All The  Customer Details");
					for (Customer customer : bankingservices.getAllCustomerDetails())
						System.out.println(customer);				
					break;
				case 10:
					System.out.println("View All The Account Detaills");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Account Details"+" "+ bankingservices.getAccountDetails(customerId, accountNo));
					break;
				case 11:
					System.out.println(" View All The Transaction Details");
					System.out.println("Enter CustomerId");
					customerId=scanner.nextInt();
					System.out.println("Enter Account Number");
					accountNo=scanner.nextLong();
					System.out.println("Transaction Details" + " "+ bankingservices.getAccountAllTransaction(customerId, accountNo));
					break;	
				default: 
					System.out.println("Enter the valid key ");
					break;	
				}
			}
			catch (BankingServicesDownException e) {
				e.printStackTrace();
			}
			catch (InvalidAmountException e) {
				e.printStackTrace();
			}
			catch (CustomerNotFoundException e) {
				e.printStackTrace();
			}
			catch (InvalidAccountTypeException e) {
				e.printStackTrace();
			}
			catch (InsufficientAmountException e) {
				e.printStackTrace();

			}
			catch (AccountNotFoundException e) {
				e.printStackTrace();
			}
			catch (InvalidPinNumberException e) {
				e.printStackTrace();
			}
			catch (AccountBlockedException e) {
				e.printStackTrace();
			}
		}*/
	}
}
	