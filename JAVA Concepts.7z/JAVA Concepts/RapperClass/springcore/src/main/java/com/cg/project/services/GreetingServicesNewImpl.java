package com.cg.project.services;

public class GreetingServicesNewImpl implements GreetingServices{
	public GreetingServicesNewImpl() {
		System.out.println("New Class Of IMPL");
	}

	public void sayHello(String personName) {
		System.out.println("Hello " + personName);
	}
	public void goodBye(String personName) {
		System.out.println("GoodBye " + personName);	
	}

}
