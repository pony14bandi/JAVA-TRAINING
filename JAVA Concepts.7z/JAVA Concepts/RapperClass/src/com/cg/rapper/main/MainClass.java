package com.cg.rapper.main;

import java.util.ArrayList;

public class MainClass {

	public static void main(String[] args) {
		int num=100;
		Integer iob = new Integer(num);
		System.out.println(num);
		
		num = iob.intValue();
		System.out.println(num);
		
		int num2=num;
		Integer iob1 = num;
		System.out.println(num2);
		
		num2=iob;
		System.out.println(num);
	
		ArrayList list = new ArrayList();
		Integer list1 = new Integer(100);
		Integer list2 = new Integer(200);
		Integer list3 = new Integer(300);
		Integer list4 = new Integer(400);
		System.out.println(list1+" "+list2);
		
		ArrayList list1 = new ArrayList();
		list1.add(100);
	}


}
