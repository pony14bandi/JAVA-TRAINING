package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.webapp.beans.UserBean;

@WebServlet("/DisplayInfoPage")
public class DisplayInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init() {
		 
	}
	public void destroy() {
		
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession();
		UserBean userBean = (UserBean) session.getAttribute("UserBean");
		userBean.setPhone(request.getParameter("phone"));
		userBean.setEmail(request.getParameter("email"));
		session.setAttribute("userBean", userBean);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("firstName :" +userBean.getFirstName());
		writer.println("<br>lastName :" +userBean.getLastName());
		writer.println("<br>city :" +userBean.getCity());
		writer.println("<br>state :" +userBean.getState());
		writer.println("<br>phone :" +userBean.getPhone());
		writer.println("<br>email :" +userBean.getEmail());
		writer.println("<form name='personalInfoPage' action='#' method='post'></form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
	}
}
