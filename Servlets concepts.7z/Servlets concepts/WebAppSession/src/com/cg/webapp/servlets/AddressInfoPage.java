package com.cg.webapp.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.webapp.beans.UserBean;

@WebServlet("/AddressInfoPage")
public class AddressInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init() {
		
	}
	public void destroy() {
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		UserBean userBean = new UserBean(firstName, lastName);
		HttpSession session = request.getSession();
		session.setAttribute("UserBean", userBean);	
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("firstName : " +userBean.getFirstName());
		writer.println("<br>lastName : " +userBean.getLastName());
		writer.println("<form name='addressInfoPage' action='CommunicationInfoPage' method='post'>");
		writer.println("<table>");
		writer.println("<tr><td>city :</td>");
		writer.println("<td><input type='text' name='city'></td></tr>");
		writer.println("<tr><td>state :</td>");
		writer.println("<td><input type='text' name='state'></td></tr>");	
		writer.println("<tr><td><input type='submit' value='submit'></td></tr>");
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
		}

	}


