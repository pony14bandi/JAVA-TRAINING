package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.webapp.beans.UserBean;

@WebServlet("/DisplayInfoPage")
public class DisplayInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext context;
	public void init() {
		 context = getServletContext();
	}
	public void destroy() {
		
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city =request.getParameter("city");
		String state=request.getParameter("state");
		String phone =request.getParameter("phone");
		String email=request.getParameter("email");
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("<table>");
		writer.println("<tr><td>firstName : </td>");
		writer.println("<td>"+firstName+"</td></tr>");
		writer.println("<tr><td>lastName : </td>");
		writer.println("<td>"+lastName+"</td></tr>");
		writer.println("<tr><td>city : </td>");
		writer.println("<td>"+city+"</td></tr>");
		writer.println("<tr><td>state : </td>");
		writer.println("<td>"+state+"</td></tr>");
		writer.println("<tr><td>phone : </td>");
		writer.println("<td>"+phone+"</td></tr>");
		writer.println("<tr><td>email : </td>");
		writer.println("<td>"+email+"</td></tr>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
	}
}
