package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/CommunicationInfoPage")
public class CommunicationInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init()  {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city= request.getParameter("city");
		String state=request.getParameter("state");
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("<form name='communicationInfoPage' action='DisplayInfoPage' method='post'>");
		writer.println("<table>");
		writer.println("<tr><td>firstName : </td>");
		writer.println("<td>"+firstName+"</td></tr>");
		writer.println("<tr>");
		writer.println("<tr><td>lastName : </td>");
		writer.println("<td>"+lastName+"</td></tr>");
		writer.println("<tr><td>city : </td>");
		writer.println("<td>"+city+"</td></tr>");
		writer.println("<tr>");
		writer.println("<tr><td>state : </td>");
		writer.println("<td>"+state+"</td></tr>");
		writer.println("<tr><td>phone :</td>");
		writer.println("<td><input type='tel' name='phone'></td></tr>");
		writer.println("<tr><td>email :</td>");
		writer.println("<td><input type='text' name='email'></td></tr>");	
		writer.println("<tr><td><input type='submit' value='submit'></td></tr>");
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
	}

}
