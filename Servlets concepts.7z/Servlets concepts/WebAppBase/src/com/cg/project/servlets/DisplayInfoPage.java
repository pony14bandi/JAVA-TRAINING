package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/DisplayInfoPage")
public class DisplayInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init() {}
	public void destroy() {	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city= request.getParameter("city");
		String state=request.getParameter("state");
		String phone= request.getParameter("phone");
		String email=request.getParameter("email");
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("<form name='personalInfoPage' action='#' method='post'>");
		writer.println("<table>");
		writer.println("firstName :" +firstName);
		writer.println("<br>lastName :" +lastName);
		writer.println("<br>city :" +city);
		writer.println("<br>state :" +state);
		writer.println("<br>phone :" +phone);
		writer.println("<br>email :" +email);
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
		
	}

}
