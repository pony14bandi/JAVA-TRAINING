package com.cg.project.beans;

import java.util.List;

public class UserBean{
	private String userName,password,firstName,lastName,email_Id,gender,graduation,EnterDetailInformation, resumeFile;
	private List<String> communication;
	public UserBean() {}
	public UserBean(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	public UserBean(String userName, String password, String firstName, String lastName, String email_Id, String gender,
			String graduation, String enterDetailInformation, String resumeFile, List<String> communication) {
		super();
		this.userName = userName;
		this.password = password;
		this.firstName = firstName;
		this.lastName = lastName;
		this.email_Id = email_Id;
		this.gender = gender;
		this.graduation = graduation;
		EnterDetailInformation = enterDetailInformation;
		this.resumeFile = resumeFile;
		this.communication = communication;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((EnterDetailInformation == null) ? 0 : EnterDetailInformation.hashCode());
		result = prime * result + ((email_Id == null) ? 0 : email_Id.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + ((graduation == null) ? 0 : graduation.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((password == null) ? 0 : password.hashCode());
		result = prime * result + ((resumeFile == null) ? 0 : resumeFile.hashCode());
		result = prime * result + ((userName == null) ? 0 : userName.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserBean other = (UserBean) obj;
		if (EnterDetailInformation == null) {
			if (other.EnterDetailInformation != null)
				return false;
		} else if (!EnterDetailInformation.equals(other.EnterDetailInformation))
			return false;
		if (email_Id == null) {
			if (other.email_Id != null)
				return false;
		} else if (!email_Id.equals(other.email_Id))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (graduation == null) {
			if (other.graduation != null)
				return false;
		} else if (!graduation.equals(other.graduation))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		if (resumeFile == null) {
			if (other.resumeFile != null)
				return false;
		} else if (!resumeFile.equals(other.resumeFile))
			return false;
		if (userName == null) {
			if (other.userName != null)
				return false;
		} else if (!userName.equals(other.userName))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "UserBean [userName=" + userName + ", password=" + password + ", firstName=" + firstName + ", lastName="
				+ lastName + ", email_Id=" + email_Id + ", gender=" + gender + ", graduation=" + graduation
				+ ", EnterDetailInformation=" + EnterDetailInformation + ", resumeFile=" + resumeFile + "]";
	}
	
}
