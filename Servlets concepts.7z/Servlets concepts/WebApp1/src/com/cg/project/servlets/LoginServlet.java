package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private Connection con;
	public void init()  {
		ServletContext servletContext = getServletContext();
		con = (Connection) servletContext.getAttribute("con");
	}
	public void destroy() {
		con=null;
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			System.out.println("service");
			String userName=request.getParameter("username");
			String password=request.getParameter("password");		
			PrintWriter writer=response.getWriter();
			RequestDispatcher dispatcher; 
			UserBean userBean=new UserBean(userName,password);
			PreparedStatement psmt=con.prepareStatement("select password from login where username=?");
			psmt.setString(1, userBean.getUserName());
			ResultSet rs = psmt.executeQuery();
			if(rs.next()){
				if(rs.getString("password").equals(userBean.getPassword())){
					dispatcher=request.getRequestDispatcher("SuccessPage.jsp");
					request.setAttribute("UserBean",userBean);
					dispatcher.forward(request, response);
				}
				else{
					dispatcher=request.getRequestDispatcher("ErrorPage.jsp");
					request.setAttribute("errorMessage", "UserName or password wrong plz try again");
					dispatcher.forward(request, response);
				}
			} 
			else
			{
				dispatcher=request.getRequestDispatcher("RegistrationPage.jsp");
				request.setAttribute("Register", "Not registered");
				dispatcher.forward(request, response);
			}
		}
		catch (SQLException e) {
			e.printStackTrace();
		}	
	}
}

