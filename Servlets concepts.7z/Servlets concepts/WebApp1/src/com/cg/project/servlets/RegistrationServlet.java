package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;

@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public RegistrationServlet() {
        super();

    }

	
	public void init(ServletConfig config) throws ServletException {
	}

	
	public void destroy() {
		
	}

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String userName=request.getParameter("userName");
		String email_Id=request.getParameter("email_Id");
		String password=request.getParameter("password");		
		String repassword=request.getParameter("re-enter password");
		String gender=request.getParameter("gender");
		String[] communication = request.getParameterValues("communication");
		List<String> communication1=Arrays.asList(communication);
		/*for (String string : communication) {
			communication1.add(string);
		}*/
		String graduation=request.getParameter("graduation");
		String  enterDetailInformation=request.getParameter("Enter Detail Information");
		String resumeFile=request.getParameter("Select resume");
		RequestDispatcher dispatcher;
		UserBean userBean = new UserBean( userName, password, firstName,  lastName,  email_Id,  gender, graduation,  enterDetailInformation,  resumeFile, communication1);
		
		
	
	}
	
	
} 

