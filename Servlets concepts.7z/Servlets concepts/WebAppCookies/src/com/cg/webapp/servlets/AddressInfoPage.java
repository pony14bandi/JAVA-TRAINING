package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/AddressInfoPage")
public class AddressInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init() {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String firstName= request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		Cookie c1 = new Cookie("firstName", firstName);
		Cookie c2 = new Cookie("lastName", lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		//writer.println("firstName : " +firstName);
		//writer.println("<br>lastName : " +lastName);
		writer.println("<form name='addressInfoPage' action='CommunicationInfoPage' method='post'>");
		writer.println("<table>");
		writer.println("<tr><td>city :</td>");
		writer.println("<td><input type='text' name='city'></td></tr>");
		writer.println("<tr><td>state :</td>");
		writer.println("<td><input type='text' name='state'></td></tr>");	
		writer.println("<tr><td><input type='submit' value='submit'></td></tr>");
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
		}

	}


