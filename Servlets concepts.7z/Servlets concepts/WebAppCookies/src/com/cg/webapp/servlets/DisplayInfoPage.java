package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/DisplayInfoPage")
public class DisplayInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init() {}
	public void destroy() {	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie [] cookies = request.getCookies();
		String firstName =" " , lastName=" ",city=" ",state=" ";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
			else if(cookie.getName().equals("city"))
				city=cookie.getValue();
			else if(cookie.getName().equals("state"))
				state=cookie.getValue();	
		}
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		Cookie c1 = new Cookie("firstName", firstName);
		Cookie c2 = new Cookie("lastName", lastName);
		Cookie c3 = new Cookie("city", city);
		Cookie c4 = new Cookie("state", state);
		Cookie c5 = new Cookie("phone", phone);
		Cookie c6 = new Cookie("email", email);
		response.addCookie(c1);
		response.addCookie(c2);
		response.addCookie(c3);
		response.addCookie(c4);
		response.addCookie(c5);
		response.addCookie(c6);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		writer.println("firstName :" +firstName);
		writer.println("<br>lastName :" +lastName);
		writer.println("<br>city :" +city);
		writer.println("<br>state :" +state);
		writer.println("<br>phone :" +phone);
		writer.println("<br>email :" +email);
		writer.println("<form name='personalInfoPage' action='#' method='post'></form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
	}
}
