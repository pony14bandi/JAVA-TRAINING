package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/PersonalInfoPage")
public class PersonalInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
		public void init()  {}
		public void destroy() {}
		protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				PrintWriter writer = response.getWriter();
				writer.println("<html>");
				writer.println("<body style=background-color: grey>");
				writer.println("<div align='center'>");
				writer.println("<font color ='red' size='20'></font>");
				writer.println("<form name='personalInfoPage' action='AddressInfoPage' method='post'>");
				writer.println("<table>");
				writer.println("<tr><td>firstName :</td>");
				writer.println("<td><input type='text' name='firstName'></td></tr>");
				writer.println("<tr><td>lastName :</td>");
				writer.println("<td><input type='text' name='lastName'></td></tr>");	
				writer.println("<tr><td><input type='submit' value='submit'></td></tr>");
				writer.println("</table>");
				writer.println("</form>");
				writer.println("</div>");
				writer.println("<body>");
				writer.println("</html>");
			}
	}

