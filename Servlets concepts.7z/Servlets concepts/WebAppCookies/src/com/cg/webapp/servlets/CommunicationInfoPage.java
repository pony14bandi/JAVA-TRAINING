package com.cg.webapp.servlets;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/CommunicationInfoPage")
public class CommunicationInfoPage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init() {}
	public void destroy() {}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cookie [] cookies = request.getCookies();
		String firstName =" " , lastName=" ";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
		}
		String city =request.getParameter("city");
		String state=  request.getParameter("state");
		Cookie c1 = new Cookie("firstName", firstName);
		Cookie c2 = new Cookie("lastName", lastName);
		Cookie c3 = new Cookie("city", city);
		Cookie c4 = new Cookie("state", state);
		response.addCookie(c1);
		response.addCookie(c2);
		response.addCookie(c3);
		response.addCookie(c4);
		PrintWriter writer = response.getWriter();
		writer.println("<html>");
		writer.println("<body style=background-color: grey>");
		writer.println("<div align='center'>");
		writer.println("<font color ='red' size='14'></font>");
		//writer.println("firstName : " +firstName);
		//writer.println("<br>lastName : " +lastName);
		//writer.println("<br>city : " +city);
		//writer.println("<br>state : " +state);
		writer.println("<form name='communicationInfoPage' action='DisplayInfoPage' method='post'>");
		writer.println("<table>");
		writer.println("<tr><td>phone :</td>");
		writer.println("<td><input type='tel' name='phone'></td></tr>");
		writer.println("<tr><td>email :</td>");
		writer.println("<td><input type='text' name='email'></td></tr>");	
		writer.println("<tr><td><input type='submit' value='submit'></td></tr>");
		writer.println("</table>");
		writer.println("</form>");
		writer.println("</div>");
		writer.println("<body>");
		writer.println("</html>");
		
	}

}
